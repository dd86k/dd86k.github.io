﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace screensaver1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            lblText.Font = new Font("Segoe UI", 124f);

            foreach (Screen scr in Screen.AllScreens)
            {
                if (scr.Primary)
                {
                    this.StartPosition = FormStartPosition.Manual;
                    this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                    lblText.Location = new Point((scr.WorkingArea.Size.Width / 2) - (lblText.Size.Width / 2),
                        (scr.WorkingArea.Size.Height / 2) - (lblText.Size.Height / 2));
                    this.WindowState = FormWindowState.Maximized;
                    this.TopMost = true;
                    this.Location = new Point(0, 0);
                    this.BackColor = Color.Black;
                    this.KeyDown += Form1_KeyDown;
                    this.MouseDown += Form1_MouseDown;
                }
                else
                {
                    FormEmpty fe = new FormEmpty();
                    fe.StartPosition = FormStartPosition.Manual;
                    fe.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                    fe.WindowState = FormWindowState.Maximized;
                    fe.TopMost = true;
                    fe.Location = scr.WorkingArea.Location;
                    fe.BackColor = Color.Black;
                    fe.KeyDown += fe_KeyDown;
                    fe.MouseDown += fe_MouseDown;
                    fe.Show();
                }
            }

            timer1.Interval = 750;
            timer1.Start();
        }

        #region Events
        void fe_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();
        }

        void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            this.Close();
        }

        void fe_KeyDown(object sender, KeyEventArgs e)
        {
            this.Close();
        }
        #endregion

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblText.Visible = !lblText.Visible;
        }
    }
}
