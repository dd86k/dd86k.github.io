﻿using System.Windows.Forms;

namespace screensaver1
{
    public partial class FormEmpty : Form
    {
        public FormEmpty()
        {

        }
    }
}
